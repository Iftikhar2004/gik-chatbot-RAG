# ui.py
# type: ignore

import gradio as gr


def build_interface(chatbot_response):
    with gr.Blocks(
        css="""
        .upload-box {
            border: 2px dashed #3b82f6 !important;
            border-radius: 12px !important;
            background: #111827 !important;
            padding: 1.5rem !important;
            text-align: center !important;
            color: #9ca3af !important;
            font-size: 0.95rem !important;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .upload-box:hover {
            background: #1f2937 !important;
            border-color: #60a5fa !important;
            color: #f9fafb !important;
        }
        .chat-input {
            display: flex;
            align-items: center;
            background: #1e293b;
            border-radius: 9999px;
            padding: 0.4rem 0.8rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.5);
        }
        .chat-input textarea {
            flex: 1;
            border: none !important;
            outline: none !important;
            background: transparent !important;
            color: white !important;
            resize: none !important;
            font-size: 1rem;
            padding-left: 0.5rem;
        }
        .chat-btn {
            background: #2563eb;
            color: white;
            border: none;
            border-radius: 9999px;
            padding: 0.6rem 0.9rem;
            cursor: pointer;
            font-size: 1.2rem;
            transition: 0.2s;
        }
        .chat-btn:hover {
            background: #1d4ed8;
        }
        .clear-btn {
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: #ef4444;
            color: white;
            border: none;
            padding: 0.6rem 1rem;
            border-radius: 10px;
            font-weight: 500;
            cursor: pointer;
            box-shadow: 0 3px 8px rgba(0,0,0,0.5);
        }
        .clear-btn:hover {
            background: #dc2626;
        }
        """
    ) as demo:

        # 🔹 Header
        gr.HTML(
            """
            <div style="text-align: center; padding: 1.5rem;
                        background: linear-gradient(90deg, #0f2027, #203a43, #2c5364);
                        color: white; border-radius: 16px; margin-bottom: 2rem;
                        box-shadow: 0 4px 12px rgba(0,0,0,0.6);">
                <h1 style="margin:0; font-size:2.4rem; font-weight:600;">
                    GIKI Prospectus Q&A Chatbot
                </h1>
                <p style="margin-top:0.6rem; font-size:1.1rem; line-height:1.6; color:#d1d5db;">
                    Interact with <b>GIKI Prospectus, Fee Structure & Rules</b> 📂 <br>
                    Powered by <b>Retrieval-Augmented Generation (RAG)</b> ⚡
                </p>
            </div>
            """
        )

        with gr.Row():

            # Left Column - Upload + Settings
            with gr.Column(scale=1):
                gr.HTML("<h3 style='color:#f9fafb;'>📂 Upload GIKI Documents</h3>")
                file_output = gr.File(
                    label="",
                    file_count="multiple",
                    file_types=[".pdf", ".docx", ".txt"],
                    elem_classes=["upload-box"],
                )

                gr.HTML("<h3 style='color:#f9fafb;'>🌐 Language</h3>")
                language_dropdown = gr.Dropdown(
                    label="Choose Answer Language",
                    choices=["English", "Urdu"],
                    value="English",
                    interactive=True,
                )

            # Right Column - Chat
            with gr.Column(scale=2):
                chatbot_ui = gr.Chatbot(
                    label="Chat with GIKI Assistant",
                    bubble_full_width=False,
                    height=500,
                    avatar_images=("👨‍🎓", "🤖"),
                )

                with gr.Row():
                    text_input = gr.Textbox(
                        placeholder="Ask about GIKI rules, fees, or academics...",
                        lines=1,
                        elem_classes=["chat-input"],
                    )
                    submit_button = gr.Button("➤", elem_classes=["chat-btn"])

        # Floating clear button
        clear_btn = gr.Button("Clear", elem_classes=["clear-btn"])

        # 🔹 Response Function
        def respond(files, message, language, history):
            response = chatbot_response(files, message, language)
            history = history + [(message, response[0][1])]
            return history, history, ""

        # Bind events
        submit_button.click(
            fn=respond,
            inputs=[file_output, text_input, language_dropdown, chatbot_ui],
            outputs=[chatbot_ui, chatbot_ui, text_input],
        )

        text_input.submit(
            fn=respond,
            inputs=[file_output, text_input, language_dropdown, chatbot_ui],
            outputs=[chatbot_ui, chatbot_ui, text_input],
        )

        clear_btn.click(lambda: None, None, chatbot_ui, queue=False)

    return demo
